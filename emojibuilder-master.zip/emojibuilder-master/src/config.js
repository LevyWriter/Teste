export default {
  assetBasePath: './assets',
  compSize: 128,
};